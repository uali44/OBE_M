module.exports = {
    options: {
        sourcemap: true
    },
    dist: {
        files: {
            '<%= yeoman.dist %>/font-awesome-animation.css': '<%= yeoman.src %>/font-awesome-animation.css'
        }
    }
};